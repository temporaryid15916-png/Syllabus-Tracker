Syllabus Tracker PWA

Host this folder on HTTPS (GitHub Pages is free). Then open the HTTPS URL in Android Chrome and choose Install app/Add to Home screen.

GitHub Pages: create repo -> upload all files -> Settings -> Pages -> Deploy from branch -> main -> root -> Save.

Progress is stored locally on the device/browser and is not automatically synced between phones.